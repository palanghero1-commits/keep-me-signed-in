import { pgTable, serial, date, boolean, timestamp, integer, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const weekSchedulesTable = pgTable("week_schedules", {
  id: serial("id").primaryKey(),
  weekStartDate: date("week_start_date").notNull(),
  weekEndDate: date("week_end_date").notNull(),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const assignmentsTable = pgTable("assignments", {
  id: serial("id").primaryKey(),
  weekScheduleId: integer("week_schedule_id")
    .notNull()
    .references(() => weekSchedulesTable.id),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id),
  dayOfWeek: integer("day_of_week").notNull(),
  dutyType: varchar("duty_type", { length: 20 }).notNull(),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notificationSettingsTable = pgTable("notification_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id)
    .unique(),
  pushEnabled: boolean("push_enabled").notNull().default(false),
  localAlarmEnabled: boolean("local_alarm_enabled").notNull().default(true),
  reminderTime: varchar("reminder_time", { length: 10 }).notNull().default("08:00"),
  reminderDays: varchar("reminder_days", { length: 50 }).notNull().default("0,1,2,3,4"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertWeekScheduleSchema = createInsertSchema(weekSchedulesTable).omit({ id: true, createdAt: true });
export const insertAssignmentSchema = createInsertSchema(assignmentsTable).omit({ id: true, createdAt: true });
export const insertNotificationSettingsSchema = createInsertSchema(notificationSettingsTable).omit({ id: true, createdAt: true, updatedAt: true });

export type InsertWeekSchedule = z.infer<typeof insertWeekScheduleSchema>;
export type WeekSchedule = typeof weekSchedulesTable.$inferSelect;
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignmentsTable.$inferSelect;
export type NotificationSettings = typeof notificationSettingsTable.$inferSelect;
