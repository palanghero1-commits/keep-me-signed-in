# Kitchen Duty Scheduler

## Overview

A full-stack office kitchen duty scheduling app. Manages 5 people across 5 weekdays (Mon-Fri) with fair assignment rotation. Each week every person gets exactly 1 rice cooking and 1 dish washing duty, with no same-day conflicts.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Frontend**: React + Vite + TailwindCSS + shadcn/ui
- **Routing**: Wouter
- **Data fetching**: TanStack React Query
- **Sessions**: express-session (cookie-based, httpOnly)
- **Build**: esbuild (CJS bundle)

## Users

Pre-seeded accounts:
- **admin** / admin123 (role: admin)
- **alice** / password (role: user)
- **bob** / password (role: user)
- **carol** / password (role: user)
- **dave** / password (role: user)
- **emma** / password (role: user)

Password hashing: `Buffer.from(password + "kitchen_salt_2024").toString("base64")`

## Structure

```text
artifacts/
├── api-server/         # Express API server (port 8080, served at /api)
│   ├── src/lib/
│   │   ├── auth.ts         # Session auth helpers
│   │   └── scheduling.ts   # Duty generation algorithm
│   └── src/routes/
│       ├── auth.ts         # POST /login, POST /logout, GET /me
│       ├── users.ts        # GET /users
│       ├── schedule.ts     # GET /current, GET /today, POST /generate, PUT /:id/assignment
│       ├── tasks.ts        # POST /:id/complete, POST /:id/uncomplete
│       ├── history.ts      # GET /history
│       └── notifications.ts # GET/PUT /settings
└── kitchen-duty/       # React frontend (port 23048, served at /)
    └── src/
        ├── pages/      # login, dashboard, today, schedule, admin, history, settings
        ├── components/ # layout, ui-elements
        └── hooks/      # use-auth
lib/
├── api-spec/openapi.yaml   # OpenAPI contract (source of truth)
├── api-client-react/       # Generated React Query hooks
├── api-zod/                # Generated Zod schemas
└── db/src/schema/
    ├── users.ts            # users table
    └── schedules.ts        # week_schedules, assignments, notification_settings tables
```

## Scheduling Algorithm

The `generateWeeklySchedule()` function in `artifacts/api-server/src/lib/scheduling.ts`:
1. Shuffles 5 user IDs randomly → rice order
2. Rotates by 2 → dishes order (guarantees no same-day overlap)
3. Assigns rice[i] and dishes[i] to day i (Mon=0, Fri=4)

## Features

- Login/logout with session cookies
- Admin and user roles
- Dashboard with today's summary
- Today's task with mark done/undone
- Full weekly schedule table view
- Admin schedule management with manual override
- Auto-generate next week's schedule
- History of past weeks
- Notification settings (push toggle, local alarm, time picker)
- Mobile-friendly responsive UI

## API Endpoints

All under `/api`:
- `POST /auth/login` — login
- `POST /auth/logout` — logout
- `GET /auth/me` — get current user
- `GET /users` — list all users
- `GET /schedule/current` — current week schedule
- `GET /schedule/today` — today's assignments
- `POST /schedule/generate` — generate new week (admin)
- `PUT /schedule/:id/assignment` — update assignment (admin)
- `POST /tasks/:id/complete` — mark task done
- `POST /tasks/:id/uncomplete` — unmark task
- `GET /history` — paginated schedule history
- `GET /notifications/settings` — get settings
- `PUT /notifications/settings` — update settings

## Development

```bash
# Install dependencies
pnpm install

# Push DB schema
pnpm --filter @workspace/db run push

# Run API server (port 8080)
pnpm --filter @workspace/api-server run dev

# Run frontend (port 23048)
pnpm --filter @workspace/kitchen-duty run dev

# Regenerate API client from spec changes
pnpm --filter @workspace/api-spec run codegen
```
