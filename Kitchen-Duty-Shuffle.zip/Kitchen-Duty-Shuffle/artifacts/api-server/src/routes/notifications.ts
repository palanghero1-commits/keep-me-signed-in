import { Router } from "express";
import { db } from "@workspace/db";
import { notificationSettingsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";
import { UpdateNotificationSettingsBody } from "@workspace/api-zod";

const router = Router();

router.get("/settings", requireAuth, async (req, res) => {
  try {
    const currentUser = (req as any).user;
    const rows = await db
      .select()
      .from(notificationSettingsTable)
      .where(eq(notificationSettingsTable.userId, currentUser.id))
      .limit(1);

    if (rows.length === 0) {
      // Create default settings
      const [created] = await db
        .insert(notificationSettingsTable)
        .values({
          userId: currentUser.id,
          pushEnabled: false,
          localAlarmEnabled: true,
          reminderTime: "08:00",
          reminderDays: "0,1,2,3,4",
        })
        .returning();
      
      res.json({
        pushEnabled: created.pushEnabled,
        localAlarmEnabled: created.localAlarmEnabled,
        reminderTime: created.reminderTime,
        reminderDays: created.reminderDays.split(",").map(Number),
      });
      return;
    }

    const settings = rows[0];
    res.json({
      pushEnabled: settings.pushEnabled,
      localAlarmEnabled: settings.localAlarmEnabled,
      reminderTime: settings.reminderTime,
      reminderDays: settings.reminderDays.split(",").map(Number),
    });
  } catch (err) {
    console.error("Get notification settings error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.put("/settings", requireAuth, async (req, res) => {
  try {
    const currentUser = (req as any).user;
    const parsed = UpdateNotificationSettingsBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Bad Request", message: "Invalid settings" });
      return;
    }

    const { pushEnabled, localAlarmEnabled, reminderTime, reminderDays } = parsed.data;
    const reminderDaysStr = reminderDays.join(",");

    const existing = await db
      .select()
      .from(notificationSettingsTable)
      .where(eq(notificationSettingsTable.userId, currentUser.id))
      .limit(1);

    if (existing.length === 0) {
      const [created] = await db
        .insert(notificationSettingsTable)
        .values({
          userId: currentUser.id,
          pushEnabled,
          localAlarmEnabled,
          reminderTime,
          reminderDays: reminderDaysStr,
          updatedAt: new Date(),
        })
        .returning();
      
      res.json({
        pushEnabled: created.pushEnabled,
        localAlarmEnabled: created.localAlarmEnabled,
        reminderTime: created.reminderTime,
        reminderDays: created.reminderDays.split(",").map(Number),
      });
    } else {
      const [updated] = await db
        .update(notificationSettingsTable)
        .set({
          pushEnabled,
          localAlarmEnabled,
          reminderTime,
          reminderDays: reminderDaysStr,
          updatedAt: new Date(),
        })
        .where(eq(notificationSettingsTable.userId, currentUser.id))
        .returning();

      res.json({
        pushEnabled: updated.pushEnabled,
        localAlarmEnabled: updated.localAlarmEnabled,
        reminderTime: updated.reminderTime,
        reminderDays: updated.reminderDays.split(",").map(Number),
      });
    }
  } catch (err) {
    console.error("Update notification settings error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
