import { Router } from "express";
import { db } from "@workspace/db";
import {
  weekSchedulesTable,
  assignmentsTable,
  usersTable,
} from "@workspace/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../lib/auth.js";
import {
  generateWeeklySchedule,
  getCurrentWeekMonday,
  getNextWeekMonday,
  getWeekFriday,
  toDateString,
  getDayName,
  getTodayDayOfWeek,
} from "../lib/scheduling.js";
import { GenerateScheduleBody, UpdateAssignmentBody } from "@workspace/api-zod";

const router = Router();

// Helper to format an assignment row with user info
async function getAssignmentsWithUsers(weekScheduleId: number) {
  const assignments = await db
    .select({
      id: assignmentsTable.id,
      weekScheduleId: assignmentsTable.weekScheduleId,
      userId: assignmentsTable.userId,
      dayOfWeek: assignmentsTable.dayOfWeek,
      dutyType: assignmentsTable.dutyType,
      completed: assignmentsTable.completed,
      completedAt: assignmentsTable.completedAt,
      userDisplayName: usersTable.displayName,
      userUsername: usersTable.username,
      userRole: usersTable.role,
      userAvatarColor: usersTable.avatarColor,
      userCreatedAt: usersTable.createdAt,
    })
    .from(assignmentsTable)
    .leftJoin(usersTable, eq(assignmentsTable.userId, usersTable.id))
    .where(eq(assignmentsTable.weekScheduleId, weekScheduleId))
    .orderBy(assignmentsTable.dayOfWeek, assignmentsTable.dutyType);

  return assignments.map((a) => ({
    id: a.id,
    weekScheduleId: a.weekScheduleId,
    userId: a.userId,
    dayOfWeek: a.dayOfWeek,
    dutyType: a.dutyType,
    completed: a.completed,
    completedAt: a.completedAt ?? null,
    user: a.userDisplayName
      ? {
          id: a.userId,
          username: a.userUsername!,
          displayName: a.userDisplayName,
          role: a.userRole!,
          avatarColor: a.userAvatarColor ?? null,
          createdAt: a.userCreatedAt!,
        }
      : null,
  }));
}

function buildDaysFromAssignments(
  weekStartDate: string,
  assignments: ReturnType<typeof getAssignmentsWithUsers> extends Promise<infer T> ? T : never
) {
  const monday = new Date(weekStartDate + "T00:00:00Z");
  return Array.from({ length: 5 }, (_, i) => {
    const date = new Date(monday);
    date.setDate(date.getDate() + i);
    const dateStr = toDateString(date);

    const dayAssignments = assignments.filter((a) => a.dayOfWeek === i);
    const rice = dayAssignments.find((a) => a.dutyType === "rice") ?? null;
    const dishes = dayAssignments.find((a) => a.dutyType === "dishes") ?? null;

    return {
      date: dateStr,
      dayName: getDayName(i),
      riceAssignment: rice,
      dishesAssignment: dishes,
      myAssignment: null as typeof rice,
    };
  });
}

// GET /api/schedule/current
router.get("/current", requireAuth, async (req, res) => {
  try {
    const today = new Date();
    const monday = getCurrentWeekMonday(today);
    const mondayStr = toDateString(monday);

    let schedules = await db
      .select()
      .from(weekSchedulesTable)
      .where(eq(weekSchedulesTable.weekStartDate, mondayStr))
      .limit(1);

    if (schedules.length === 0) {
      // Auto-generate current week if it doesn't exist
      const users = await db.select().from(usersTable).orderBy(usersTable.id);
      if (users.length !== 5) {
        res.status(500).json({ error: "Server Error", message: "Need exactly 5 users" });
        return;
      }

      const friday = getWeekFriday(monday);
      const [newSchedule] = await db
        .insert(weekSchedulesTable)
        .values({
          weekStartDate: mondayStr,
          weekEndDate: toDateString(friday),
          isActive: true,
        })
        .returning();

      // Deactivate others
      await db
        .update(weekSchedulesTable)
        .set({ isActive: false })
        .where(eq(weekSchedulesTable.isActive, true));
      await db
        .update(weekSchedulesTable)
        .set({ isActive: true })
        .where(eq(weekSchedulesTable.id, newSchedule.id));

      const dayAssignments = generateWeeklySchedule(users.map((u) => u.id));
      for (const day of dayAssignments) {
        await db.insert(assignmentsTable).values([
          { weekScheduleId: newSchedule.id, userId: day.riceUserId, dayOfWeek: day.dayOfWeek, dutyType: "rice", completed: false },
          { weekScheduleId: newSchedule.id, userId: day.dishesUserId, dayOfWeek: day.dayOfWeek, dutyType: "dishes", completed: false },
        ]);
      }
      schedules = [newSchedule];
    }

    const schedule = schedules[0];
    const assignments = await getAssignmentsWithUsers(schedule.id);
    const days = buildDaysFromAssignments(schedule.weekStartDate, assignments);

    // Inject myAssignment
    const currentUser = (req as any).user;
    for (const day of days) {
      const mine = assignments.find((a) => a.dayOfWeek === day.date.length && a.userId === currentUser.id);
      day.myAssignment = assignments.find(
        (a) => a.userId === currentUser.id && a.dayOfWeek === days.indexOf(day)
      ) ?? null;
    }

    res.json({ schedule, days, assignments });
  } catch (err) {
    console.error("Get current schedule error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// GET /api/schedule/today
router.get("/today", requireAuth, async (req, res) => {
  try {
    const today = new Date();
    const todayDayOfWeek = getTodayDayOfWeek();
    const monday = getCurrentWeekMonday(today);
    const mondayStr = toDateString(monday);

    if (todayDayOfWeek === -1) {
      // Weekend
      res.json({
        date: toDateString(today),
        dayName: "Weekend",
        riceAssignment: null,
        dishesAssignment: null,
        myAssignment: null,
      });
      return;
    }

    const schedules = await db
      .select()
      .from(weekSchedulesTable)
      .where(eq(weekSchedulesTable.weekStartDate, mondayStr))
      .limit(1);

    if (schedules.length === 0) {
      res.json({
        date: toDateString(today),
        dayName: getDayName(todayDayOfWeek),
        riceAssignment: null,
        dishesAssignment: null,
        myAssignment: null,
      });
      return;
    }

    const schedule = schedules[0];
    const allAssignments = await getAssignmentsWithUsers(schedule.id);
    const todayAssignments = allAssignments.filter((a) => a.dayOfWeek === todayDayOfWeek);

    const rice = todayAssignments.find((a) => a.dutyType === "rice") ?? null;
    const dishes = todayAssignments.find((a) => a.dutyType === "dishes") ?? null;
    const currentUser = (req as any).user;
    const myAssignment = todayAssignments.find((a) => a.userId === currentUser.id) ?? null;

    res.json({
      date: toDateString(today),
      dayName: getDayName(todayDayOfWeek),
      riceAssignment: rice,
      dishesAssignment: dishes,
      myAssignment,
    });
  } catch (err) {
    console.error("Get today assignment error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// POST /api/schedule/generate
router.post("/generate", requireAdmin, async (req, res) => {
  try {
    const parsed = GenerateScheduleBody.safeParse(req.body);
    let startDate: string;

    if (parsed.success && parsed.data.weekStartDate) {
      startDate = parsed.data.weekStartDate;
    } else {
      const nextMonday = getNextWeekMonday();
      startDate = toDateString(nextMonday);
    }

    const monday = new Date(startDate + "T00:00:00Z");
    const friday = getWeekFriday(monday);

    // Check if schedule already exists
    const existing = await db
      .select()
      .from(weekSchedulesTable)
      .where(eq(weekSchedulesTable.weekStartDate, startDate))
      .limit(1);

    if (existing.length > 0) {
      // Return existing
      const schedule = existing[0];
      const assignments = await getAssignmentsWithUsers(schedule.id);
      const days = buildDaysFromAssignments(schedule.weekStartDate, assignments);
      res.json({ schedule, days, assignments });
      return;
    }

    const users = await db.select().from(usersTable).orderBy(usersTable.id);
    if (users.length !== 5) {
      res.status(500).json({ error: "Server Error", message: "Need exactly 5 users" });
      return;
    }

    // Deactivate current active schedule
    await db
      .update(weekSchedulesTable)
      .set({ isActive: false })
      .where(eq(weekSchedulesTable.isActive, true));

    const [newSchedule] = await db
      .insert(weekSchedulesTable)
      .values({
        weekStartDate: startDate,
        weekEndDate: toDateString(friday),
        isActive: true,
      })
      .returning();

    const dayAssignments = generateWeeklySchedule(users.map((u) => u.id));
    for (const day of dayAssignments) {
      await db.insert(assignmentsTable).values([
        { weekScheduleId: newSchedule.id, userId: day.riceUserId, dayOfWeek: day.dayOfWeek, dutyType: "rice", completed: false },
        { weekScheduleId: newSchedule.id, userId: day.dishesUserId, dayOfWeek: day.dayOfWeek, dutyType: "dishes", completed: false },
      ]);
    }

    const assignments = await getAssignmentsWithUsers(newSchedule.id);
    const days = buildDaysFromAssignments(newSchedule.weekStartDate, assignments);

    res.json({ schedule: newSchedule, days, assignments });
  } catch (err) {
    console.error("Generate schedule error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// PUT /api/schedule/:scheduleId/assignment
router.put("/:scheduleId/assignment", requireAdmin, async (req, res) => {
  try {
    const scheduleId = parseInt(req.params.scheduleId);
    const parsed = UpdateAssignmentBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Bad Request", message: "Invalid request body" });
      return;
    }
    const { userId, dutyType, dayOfWeek } = parsed.data;

    // Check that assigning this user won't cause a same-day conflict
    const sameDay = await db
      .select()
      .from(assignmentsTable)
      .where(
        and(
          eq(assignmentsTable.weekScheduleId, scheduleId),
          eq(assignmentsTable.dayOfWeek, dayOfWeek),
          eq(assignmentsTable.userId, userId)
        )
      )
      .limit(1);

    const existingDutySlot = await db
      .select()
      .from(assignmentsTable)
      .where(
        and(
          eq(assignmentsTable.weekScheduleId, scheduleId),
          eq(assignmentsTable.dayOfWeek, dayOfWeek),
          eq(assignmentsTable.dutyType, dutyType)
        )
      )
      .limit(1);

    if (sameDay.length > 0 && sameDay[0].dutyType !== dutyType) {
      res.status(400).json({
        error: "Conflict",
        message: "User already has a different duty on this day",
      });
      return;
    }

    if (existingDutySlot.length > 0) {
      // Update the existing slot
      const [updated] = await db
        .update(assignmentsTable)
        .set({ userId })
        .where(eq(assignmentsTable.id, existingDutySlot[0].id))
        .returning();

      const withUser = await getAssignmentsWithUsers(scheduleId);
      const result = withUser.find((a) => a.id === updated.id);
      res.json(result ?? updated);
    } else {
      const [inserted] = await db
        .insert(assignmentsTable)
        .values({
          weekScheduleId: scheduleId,
          userId,
          dayOfWeek,
          dutyType,
          completed: false,
        })
        .returning();

      const withUser = await getAssignmentsWithUsers(scheduleId);
      const result = withUser.find((a) => a.id === inserted.id);
      res.json(result ?? inserted);
    }
  } catch (err) {
    console.error("Update assignment error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
