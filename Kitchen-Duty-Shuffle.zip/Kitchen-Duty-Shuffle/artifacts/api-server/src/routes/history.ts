import { Router } from "express";
import { db } from "@workspace/db";
import {
  weekSchedulesTable,
  assignmentsTable,
  usersTable,
} from "@workspace/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";
import { getDayName, toDateString } from "../lib/scheduling.js";
import { GetHistoryQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const parsed = GetHistoryQueryParams.safeParse(req.query);
    const limit = parsed.success ? (parsed.data.limit ?? 10) : 10;
    const offset = parsed.success ? (parsed.data.offset ?? 0) : 0;

    const allSchedules = await db
      .select()
      .from(weekSchedulesTable)
      .orderBy(desc(weekSchedulesTable.weekStartDate));

    const total = allSchedules.length;
    const pageSchedules = allSchedules.slice(offset, offset + limit);

    const items = await Promise.all(
      pageSchedules.map(async (schedule) => {
        const assignments = await db
          .select({
            id: assignmentsTable.id,
            weekScheduleId: assignmentsTable.weekScheduleId,
            userId: assignmentsTable.userId,
            dayOfWeek: assignmentsTable.dayOfWeek,
            dutyType: assignmentsTable.dutyType,
            completed: assignmentsTable.completed,
            completedAt: assignmentsTable.completedAt,
            userDisplayName: usersTable.displayName,
            userUsername: usersTable.username,
            userRole: usersTable.role,
            userAvatarColor: usersTable.avatarColor,
            userCreatedAt: usersTable.createdAt,
          })
          .from(assignmentsTable)
          .leftJoin(usersTable, eq(assignmentsTable.userId, usersTable.id))
          .where(eq(assignmentsTable.weekScheduleId, schedule.id))
          .orderBy(assignmentsTable.dayOfWeek, assignmentsTable.dutyType);

        const formattedAssignments = assignments.map((a) => ({
          id: a.id,
          weekScheduleId: a.weekScheduleId,
          userId: a.userId,
          dayOfWeek: a.dayOfWeek,
          dutyType: a.dutyType,
          completed: a.completed,
          completedAt: a.completedAt ?? null,
          user: a.userDisplayName
            ? {
                id: a.userId,
                username: a.userUsername!,
                displayName: a.userDisplayName,
                role: a.userRole!,
                avatarColor: a.userAvatarColor ?? null,
                createdAt: a.userCreatedAt!,
              }
            : null,
        }));

        const monday = new Date(schedule.weekStartDate + "T00:00:00Z");
        const days = Array.from({ length: 5 }, (_, i) => {
          const date = new Date(monday);
          date.setDate(date.getDate() + i);
          const dateStr = toDateString(date);
          const dayAssignments = formattedAssignments.filter((a) => a.dayOfWeek === i);
          return {
            date: dateStr,
            dayName: getDayName(i),
            riceAssignment: dayAssignments.find((a) => a.dutyType === "rice") ?? null,
            dishesAssignment: dayAssignments.find((a) => a.dutyType === "dishes") ?? null,
            myAssignment: null,
          };
        });

        return { schedule, days, assignments: formattedAssignments };
      })
    );

    res.json({ total, items });
  } catch (err) {
    console.error("Get history error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
