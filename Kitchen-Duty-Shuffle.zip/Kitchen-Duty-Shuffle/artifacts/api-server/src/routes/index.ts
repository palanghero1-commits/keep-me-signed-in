import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import usersRouter from "./users.js";
import scheduleRouter from "./schedule.js";
import tasksRouter from "./tasks.js";
import historyRouter from "./history.js";
import notificationsRouter from "./notifications.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/schedule", scheduleRouter);
router.use("/tasks", tasksRouter);
router.use("/history", historyRouter);
router.use("/notifications", notificationsRouter);

export default router;
