import { Router } from "express";
import { db } from "@workspace/db";
import { assignmentsTable, usersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";

const router = Router();

async function getAssignmentWithUser(id: number) {
  const rows = await db
    .select({
      id: assignmentsTable.id,
      weekScheduleId: assignmentsTable.weekScheduleId,
      userId: assignmentsTable.userId,
      dayOfWeek: assignmentsTable.dayOfWeek,
      dutyType: assignmentsTable.dutyType,
      completed: assignmentsTable.completed,
      completedAt: assignmentsTable.completedAt,
      userDisplayName: usersTable.displayName,
      userUsername: usersTable.username,
      userRole: usersTable.role,
      userAvatarColor: usersTable.avatarColor,
      userCreatedAt: usersTable.createdAt,
    })
    .from(assignmentsTable)
    .leftJoin(usersTable, eq(assignmentsTable.userId, usersTable.id))
    .where(eq(assignmentsTable.id, id))
    .limit(1);

  const a = rows[0];
  if (!a) return null;
  return {
    id: a.id,
    weekScheduleId: a.weekScheduleId,
    userId: a.userId,
    dayOfWeek: a.dayOfWeek,
    dutyType: a.dutyType,
    completed: a.completed,
    completedAt: a.completedAt ?? null,
    user: a.userDisplayName
      ? {
          id: a.userId,
          username: a.userUsername!,
          displayName: a.userDisplayName,
          role: a.userRole!,
          avatarColor: a.userAvatarColor ?? null,
          createdAt: a.userCreatedAt!,
        }
      : null,
  };
}

router.post("/:assignmentId/complete", requireAuth, async (req, res) => {
  try {
    const assignmentId = parseInt(req.params.assignmentId);
    if (isNaN(assignmentId)) {
      res.status(400).json({ error: "Bad Request", message: "Invalid assignment ID" });
      return;
    }

    const currentUser = (req as any).user;
    const existing = await getAssignmentWithUser(assignmentId);
    if (!existing) {
      res.status(404).json({ error: "Not Found", message: "Assignment not found" });
      return;
    }

    // Users can only complete their own assignments; admins can complete any
    if (currentUser.role !== "admin" && existing.userId !== currentUser.id) {
      res.status(403).json({ error: "Forbidden", message: "Can only complete your own tasks" });
      return;
    }

    await db
      .update(assignmentsTable)
      .set({ completed: true, completedAt: new Date() })
      .where(eq(assignmentsTable.id, assignmentId));

    const updated = await getAssignmentWithUser(assignmentId);
    res.json(updated);
  } catch (err) {
    console.error("Complete task error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/:assignmentId/uncomplete", requireAuth, async (req, res) => {
  try {
    const assignmentId = parseInt(req.params.assignmentId);
    if (isNaN(assignmentId)) {
      res.status(400).json({ error: "Bad Request", message: "Invalid assignment ID" });
      return;
    }

    const currentUser = (req as any).user;
    const existing = await getAssignmentWithUser(assignmentId);
    if (!existing) {
      res.status(404).json({ error: "Not Found", message: "Assignment not found" });
      return;
    }

    if (currentUser.role !== "admin" && existing.userId !== currentUser.id) {
      res.status(403).json({ error: "Forbidden", message: "Can only update your own tasks" });
      return;
    }

    await db
      .update(assignmentsTable)
      .set({ completed: false, completedAt: null })
      .where(eq(assignmentsTable.id, assignmentId));

    const updated = await getAssignmentWithUser(assignmentId);
    res.json(updated);
  } catch (err) {
    console.error("Uncomplete task error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
