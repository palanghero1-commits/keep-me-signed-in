/**
 * Scheduling logic for kitchen duty assignments.
 * Generates a fair weekly schedule ensuring:
 * - Each person gets exactly 1 rice and 1 dishes assignment per week
 * - No person is assigned both rice and dishes on the same day
 * - Assignments are shuffled fairly
 */

export interface DayAssignments {
  dayOfWeek: number; // 0=Monday, 1=Tuesday, ... 4=Friday
  riceUserId: number;
  dishesUserId: number;
}

/**
 * Fisher-Yates shuffle
 */
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Generate a weekly schedule for 5 people across 5 weekdays.
 * 
 * Algorithm:
 * 1. Shuffle user IDs to get a random rice order [u0, u1, u2, u3, u4]
 * 2. Rotate that list by 2 to get dishes order [u2, u3, u4, u0, u1]
 *    This guarantees no overlap on any given day.
 * 3. Assign rice[i] and dishes[i] to day i.
 */
export function generateWeeklySchedule(userIds: number[]): DayAssignments[] {
  if (userIds.length !== 5) {
    throw new Error("Must have exactly 5 users to generate a schedule");
  }

  const riceOrder = shuffle(userIds);
  // Rotate by 2 to ensure no same-day conflict
  const offset = 2;
  const dishesOrder = [
    ...riceOrder.slice(offset),
    ...riceOrder.slice(0, offset),
  ];

  return Array.from({ length: 5 }, (_, i) => ({
    dayOfWeek: i,
    riceUserId: riceOrder[i],
    dishesUserId: dishesOrder[i],
  }));
}

/**
 * Get the Monday of the current week
 */
export function getCurrentWeekMonday(fromDate?: Date): Date {
  const d = fromDate ? new Date(fromDate) : new Date();
  const day = d.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  const diff = (day === 0 ? -6 : 1 - day); // adjust to Monday
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

/**
 * Get the Monday of next week
 */
export function getNextWeekMonday(fromDate?: Date): Date {
  const monday = getCurrentWeekMonday(fromDate);
  monday.setDate(monday.getDate() + 7);
  return monday;
}

/**
 * Get the Friday of a week given its Monday
 */
export function getWeekFriday(monday: Date): Date {
  const friday = new Date(monday);
  friday.setDate(friday.getDate() + 4);
  return friday;
}

/**
 * Format a date as YYYY-MM-DD
 */
export function toDateString(date: Date): string {
  return date.toISOString().split("T")[0];
}

/**
 * Get day name for dayOfWeek index (0=Monday)
 */
export function getDayName(dayOfWeek: number): string {
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  return days[dayOfWeek] ?? "Unknown";
}

/**
 * Get today's dayOfWeek (0=Monday, 4=Friday) or -1 if weekend
 */
export function getTodayDayOfWeek(): number {
  const day = new Date().getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  if (day === 0 || day === 6) return -1; // Weekend
  return day - 1; // Convert to 0=Monday
}
