import { db } from "@workspace/db";
import { usersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import type { Request, Response, NextFunction } from "express";

// Simple password hash - in production use bcrypt
// Using a simple hash for demo purposes
function simpleHash(password: string): string {
  // Simple base64 encoding for demo - not production-safe
  return Buffer.from(password + "kitchen_salt_2024").toString("base64");
}

export function hashPassword(password: string): string {
  return simpleHash(password);
}

export function verifyPassword(password: string, hash: string): boolean {
  return simpleHash(password) === hash;
}

export async function getUserFromSession(req: Request) {
  const userId = (req.session as any)?.userId;
  if (!userId) return null;

  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  return users[0] ?? null;
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = await getUserFromSession(req);
  if (!user) {
    res.status(401).json({ error: "Unauthorized", message: "Please log in" });
    return;
  }
  (req as any).user = user;
  next();
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = await getUserFromSession(req);
  if (!user) {
    res.status(401).json({ error: "Unauthorized", message: "Please log in" });
    return;
  }
  if (user.role !== "admin") {
    res.status(403).json({ error: "Forbidden", message: "Admin access required" });
    return;
  }
  (req as any).user = user;
  next();
}
