import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Loader2, Home, CalendarDays, CheckCircle2, Bell, History, Settings, LogOut } from "lucide-react";
import { Avatar } from "./ui-elements";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout, isAdmin } = useAuth();

  const navItems = [
    { icon: Home, label: "Home", href: "/dashboard" },
    { icon: CheckCircle2, label: "Today", href: "/today" },
    { icon: CalendarDays, label: "Schedule", href: "/schedule" },
    { icon: History, label: "History", href: "/history" },
  ];

  if (isAdmin) {
    navItems.push({ icon: Settings, label: "Admin", href: "/admin" });
  }

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0 md:pt-20">
      {/* Top Header */}
      <header className="fixed top-0 left-0 right-0 z-40 glass-panel border-b border-border/50 px-4 h-16 flex items-center justify-between md:px-8">
        <div className="flex items-center gap-2">
          <img src={`${import.meta.env.BASE_URL}images/logo.png`} alt="Logo" className="w-8 h-8 object-contain rounded-lg" />
          <h1 className="font-display font-bold text-lg hidden sm:block">Kitchen Duty</h1>
        </div>

        {user && (
          <div className="flex items-center gap-4">
            <Link href="/settings" className="p-2 text-muted-foreground hover:text-primary transition-colors bg-black/5 rounded-full">
              <Bell className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-3 bg-white pl-2 pr-4 py-1.5 rounded-full border border-border shadow-sm">
              <Avatar name={user.displayName} color={user.avatarColor} className="w-8 h-8 text-sm" />
              <span className="text-sm font-medium hidden sm:block">{user.displayName}</span>
              <button 
                onClick={() => logout.mutate()}
                className="ml-2 text-muted-foreground hover:text-destructive transition-colors"
                title="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto p-4 md:p-8 pt-20 md:pt-8 min-h-[calc(100vh-4rem)]">
        {children}
      </main>

      {/* Bottom Nav (Mobile) & Side/Top Nav elements */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-border pb-safe md:hidden shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
        <div className="flex items-center justify-around px-2 py-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={cn(
                  "flex flex-col items-center justify-center w-16 gap-1 transition-all duration-300",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <div className={cn(
                  "p-1.5 rounded-xl transition-all duration-300",
                  isActive && "bg-primary/10"
                )}>
                  <Icon className={cn("w-6 h-6", isActive && "fill-primary/20")} strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  React.useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return isAuthenticated ? <AppLayout>{children}</AppLayout> : null;
}
