import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlarmClock, X } from "lucide-react";
import { stopAlarm } from "@/lib/alarm";

interface AlarmOverlayProps {
  isOpen: boolean;
  onDismiss: () => void;
  dutyType?: string;
  userName?: string;
}

export function AlarmOverlay({ isOpen, onDismiss, dutyType, userName }: AlarmOverlayProps) {
  // Auto-dismiss after 5 minutes if user doesn't respond
  useEffect(() => {
    if (!isOpen) return;
    const t = setTimeout(() => {
      stopAlarm();
      onDismiss();
    }, 5 * 60 * 1000);
    return () => clearTimeout(t);
  }, [isOpen, onDismiss]);

  const handleDismiss = () => {
    stopAlarm();
    onDismiss();
  };

  const dutyLabel = dutyType === "rice" ? "🍚 Cook Rice" : dutyType === "dishes" ? "🫧 Wash Dishes" : "Kitchen Duty";

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="alarm-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-br from-orange-500 via-red-500 to-rose-600"
          style={{ touchAction: "none" }}
        >
          {/* Pulsing ring */}
          <motion.div
            animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.15, 0.4] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            className="absolute w-72 h-72 rounded-full bg-white/30"
          />
          <motion.div
            animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.1, 0.3] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
            className="absolute w-96 h-96 rounded-full bg-white/20"
          />

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center gap-6 text-white text-center px-8">
            <motion.div
              animate={{ rotate: [-15, 15, -15] }}
              transition={{ duration: 0.4, repeat: Infinity, ease: "easeInOut" }}
            >
              <AlarmClock className="w-24 h-24 drop-shadow-2xl" />
            </motion.div>

            <div className="space-y-2">
              <p className="text-white/80 text-lg font-medium uppercase tracking-widest">Kitchen Alarm</p>
              <h1 className="text-5xl font-black drop-shadow-lg">{dutyLabel}</h1>
              {userName && (
                <p className="text-white/90 text-xl mt-1">
                  It's <span className="font-bold">{userName}</span>'s turn!
                </p>
              )}
            </div>

            <p className="text-white/70 text-sm max-w-xs">
              Time to take care of your kitchen duty. Tap below to acknowledge.
            </p>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleDismiss}
              className="mt-4 flex items-center gap-3 bg-white text-red-500 font-black text-xl px-10 py-5 rounded-3xl shadow-2xl active:shadow-lg"
            >
              <X className="w-6 h-6" />
              Dismiss Alarm
            </motion.button>

            <p className="text-white/50 text-xs">Auto-dismisses in 5 minutes</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
