import React, { ButtonHTMLAttributes, InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg";
  isLoading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", isLoading, children, disabled, ...props }, ref) => {
    const variants = {
      primary: "bg-gradient-to-r from-primary to-orange-400 text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 border-none",
      secondary: "bg-white text-foreground shadow-sm border border-border hover:bg-orange-50 hover:border-orange-200 hover:text-primary active:bg-orange-100",
      outline: "border-2 border-primary text-primary hover:bg-primary/5 active:bg-primary/10",
      ghost: "text-muted-foreground hover:text-foreground hover:bg-black/5 active:bg-black/10",
      destructive: "bg-destructive text-white shadow-md shadow-destructive/20 hover:bg-destructive/90 hover:shadow-lg",
    };

    const sizes = {
      sm: "px-3 py-1.5 text-sm rounded-lg",
      md: "px-5 py-2.5 text-base rounded-xl font-medium",
      lg: "px-6 py-3.5 text-lg rounded-2xl font-semibold",
    };

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(
          "relative inline-flex items-center justify-center transition-all duration-200 ease-out focus:outline-none focus:ring-4 focus:ring-primary/20",
          "disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {isLoading && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="w-full space-y-1.5">
        {label && <label className="text-sm font-semibold text-foreground/80">{label}</label>}
        <input
          ref={ref}
          className={cn(
            "w-full px-4 py-3 bg-white border-2 border-border rounded-xl text-foreground placeholder:text-muted-foreground/60 transition-all duration-200",
            "focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10",
            error && "border-destructive focus:border-destructive focus:ring-destructive/10",
            className
          )}
          {...props}
        />
        {error && <p className="text-xs text-destructive font-medium">{error}</p>}
      </div>
    );
  }
);
Input.displayName = "Input";

export function Card({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: "easeOut" }}
      className={cn("bg-white rounded-3xl p-6 shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-black/[0.03]", className)}
    >
      {children}
    </motion.div>
  );
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0] ?? "")
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function Avatar({ name, color, className }: { name: string; color?: string | null; className?: string }) {
  // Generate a consistent warm color if none provided
  const fallbackColors = ['bg-orange-400', 'bg-amber-400', 'bg-rose-400', 'bg-yellow-500', 'bg-red-400'];
  const charCode = name.charCodeAt(0) || 0;
  const bgColor = color ? `bg-[${color}]` : fallbackColors[charCode % fallbackColors.length];

  return (
    <div className={cn("relative flex items-center justify-center rounded-full text-white font-bold shadow-inner", bgColor, className)} style={color ? { backgroundColor: color } : undefined}>
      {getInitials(name)}
    </div>
  );
}
