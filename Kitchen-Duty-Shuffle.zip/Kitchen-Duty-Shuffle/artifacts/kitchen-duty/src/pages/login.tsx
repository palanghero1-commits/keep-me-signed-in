import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { Button, Input } from "@/components/ui-elements";
import { Download, X } from "lucide-react";

// Capture the install prompt before it disappears
let deferredInstallPrompt: any = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
});

export default function Login() {
  const [, setLocation] = useLocation();
  const { login, isAuthenticated } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState("");
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  // Redirect when already logged in
  useEffect(() => {
    if (isAuthenticated) setLocation("/dashboard");
  }, [isAuthenticated, setLocation]);

  // Show install banner if PWA not yet installed
  useEffect(() => {
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true;

    if (!isStandalone && !localStorage.getItem("install-dismissed")) {
      // Show after a short delay
      const t = setTimeout(() => setShowInstallBanner(true), 2000);
      return () => clearTimeout(t);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    login.mutate(
      { data: { username, password, rememberMe } },
      {
        onError: (err: any) => {
          setError(err?.data?.message || err.message || "Invalid credentials");
        },
      }
    );
  };

  const handleInstall = async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    const choice = await deferredInstallPrompt.userChoice;
    if (choice.outcome === "accepted") {
      deferredInstallPrompt = null;
      setShowInstallBanner(false);
    }
  };

  const dismissInstall = () => {
    setShowInstallBanner(false);
    localStorage.setItem("install-dismissed", "1");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden px-4">
      {/* Background Image */}
      <img
        src={`${import.meta.env.BASE_URL}images/login-bg.png`}
        alt=""
        className="absolute inset-0 w-full h-full object-cover opacity-50 mix-blend-multiply pointer-events-none"
      />

      {/* Install banner */}
      <AnimatePresence>
        {showInstallBanner && (
          <motion.div
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -80, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed top-4 left-4 right-4 z-50 max-w-md mx-auto"
          >
            <div className="bg-white rounded-2xl shadow-xl border border-orange-100 px-4 py-3 flex items-center gap-3">
              <div className="flex-shrink-0 w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
                <Download className="w-5 h-5 text-orange-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-foreground">Add to Home Screen</p>
                <p className="text-xs text-muted-foreground truncate">
                  Install for offline access & alarms
                </p>
              </div>
              <button
                onClick={handleInstall}
                className="shrink-0 px-3 py-1.5 bg-primary text-white text-xs font-bold rounded-lg"
              >
                Install
              </button>
              <button onClick={dismissInstall} className="shrink-0 text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Login card */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-white/80 backdrop-blur-xl rounded-[2rem] p-8 sm:p-12 relative z-10 shadow-2xl shadow-orange-200/30 border border-white"
      >
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-white to-orange-50 shadow-xl shadow-orange-100 mb-6 border border-white">
            <img
              src={`${import.meta.env.BASE_URL}images/logo.png`}
              alt="Kitchen Duty"
              className="w-12 h-12"
            />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Welcome Back</h1>
          <p className="text-muted-foreground">Log in to manage your kitchen duties.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <Input
            label="Username"
            placeholder="e.g. alice"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            required
          />
          <Input
            type="password"
            label="Password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            required
            error={error}
          />

          {/* Keep me signed in */}
          <label className="flex items-center gap-3 cursor-pointer select-none group">
            <div
              onClick={() => setRememberMe((v) => !v)}
              className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all duration-150 ${
                rememberMe
                  ? "bg-primary border-primary"
                  : "bg-white border-border group-hover:border-primary/50"
              }`}
            >
              {rememberMe && (
                <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12">
                  <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </div>
            <span className="text-sm text-foreground/80">
              Keep me signed in for <span className="font-semibold">30 days</span>
            </span>
          </label>

          <Button
            type="submit"
            className="w-full mt-2"
            size="lg"
            isLoading={login.isPending}
          >
            Sign In
          </Button>
        </form>

        <div className="mt-10 pt-6 border-t border-black/5 text-center">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-3">
            Demo Credentials
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            <span className="px-3 py-1 bg-black/5 rounded-full text-xs font-mono text-foreground/80">
              admin / admin123
            </span>
            <span className="px-3 py-1 bg-black/5 rounded-full text-xs font-mono text-foreground/80">
              alice / password
            </span>
            <span className="px-3 py-1 bg-black/5 rounded-full text-xs font-mono text-foreground/80">
              bob / password
            </span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
