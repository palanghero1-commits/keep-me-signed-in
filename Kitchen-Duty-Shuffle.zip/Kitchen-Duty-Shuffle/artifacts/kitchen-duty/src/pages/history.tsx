import React, { useState } from "react";
import { format } from "date-fns";
import { useGetHistory } from "@workspace/api-client-react";
import { Card, Avatar } from "@/components/ui-elements";
import { Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function History() {
  const [page, setPage] = useState(1);
  const limit = 10;
  const { data, isLoading } = useGetHistory({ limit, offset: (page - 1) * limit });
  const [expandedId, setExpandedId] = useState<number | null>(null);

  if (isLoading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold">Past Schedules</h1>
        <p className="text-muted-foreground">Look back at previous kitchen duties.</p>
      </div>

      {!data?.items?.length ? (
        <Card className="text-center py-12">
          <p className="text-muted-foreground">No history available yet.</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {data.items.map((week, index) => (
            <Card key={week.schedule.id} delay={index * 0.05} className="p-0 overflow-hidden">
              <button
                className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-black/[0.02] transition-colors focus:outline-none"
                onClick={() => setExpandedId(expandedId === week.schedule.id ? null : week.schedule.id)}
              >
                <div>
                  <h3 className="font-bold text-lg">
                    Week of {format(new Date(week.schedule.weekStartDate), "MMM d, yyyy")}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {week.assignments.filter(a => a.completed).length} / {week.assignments.length} duties completed
                  </p>
                </div>
                <div className="text-muted-foreground bg-black/5 p-2 rounded-full">
                  {expandedId === week.schedule.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>
              
              <AnimatePresence>
                {expandedId === week.schedule.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-border"
                  >
                    <div className="p-6 bg-black/[0.01]">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {week.days.map(day => (
                          <div key={day.date} className="bg-white p-4 rounded-xl border border-border shadow-sm flex items-center justify-between">
                            <div className="w-16">
                              <span className="font-bold text-sm">{day.dayName}</span>
                            </div>
                            <div className="flex-1 grid grid-cols-2 gap-2 text-sm">
                              <div className="flex items-center gap-2">
                                <Avatar name={day.riceAssignment?.user?.displayName || "?"} className="w-6 h-6 text-[10px]" />
                                <span className="truncate w-20">{day.riceAssignment?.user?.displayName || "-"}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Avatar name={day.dishesAssignment?.user?.displayName || "?"} className="w-6 h-6 text-[10px]" />
                                <span className="truncate w-20">{day.dishesAssignment?.user?.displayName || "-"}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
