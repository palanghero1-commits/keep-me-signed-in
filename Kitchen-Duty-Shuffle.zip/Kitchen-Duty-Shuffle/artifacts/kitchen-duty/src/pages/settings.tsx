import React, { useState, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetNotificationSettings,
  useUpdateNotificationSettings,
} from "@workspace/api-client-react";
import { Card, Button } from "@/components/ui-elements";
import { AlarmOverlay } from "@/components/alarm-overlay";
import {
  startAlarm,
  stopAlarm,
  unlockAudio,
  startScheduler,
  stopScheduler,
} from "@/lib/alarm";
import { useAuth } from "@/hooks/use-auth";
import {
  Loader2,
  Bell,
  AlarmClock,
  Clock,
  CalendarDays,
  Volume2,
  Smartphone,
  ShieldAlert,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user, isAdmin } = useAuth();
  const { data: settings, isLoading } = useGetNotificationSettings();
  const audioUnlocked = useRef(false);

  const [alarmVisible, setAlarmVisible] = useState(false);
  const [testing, setTesting] = useState(false);

  const updateMutation = useUpdateNotificationSettings({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({
          queryKey: ["/api/notifications/settings"],
        });
        toast({
          title: "Settings saved",
          description: "Alarm preferences updated.",
        });
        // Restart scheduler with new settings
        startScheduler(data.reminderTime, data.reminderDays, () => {
          setAlarmVisible(true);
          startAlarm();
        });
      },
    },
  });

  const [form, setForm] = useState({
    pushEnabled: false,
    localAlarmEnabled: true,
    reminderTime: "09:00",
    reminderDays: [0, 1, 2, 3, 4] as number[],
  });

  useEffect(() => {
    if (settings) {
      setForm({
        pushEnabled: settings.pushEnabled,
        localAlarmEnabled: settings.localAlarmEnabled,
        reminderTime: settings.reminderTime || "09:00",
        reminderDays: settings.reminderDays || [0, 1, 2, 3, 4],
      });
      // Start scheduler on page load using saved settings
      if (settings.localAlarmEnabled) {
        startScheduler(settings.reminderTime, settings.reminderDays, () => {
          setAlarmVisible(true);
          startAlarm();
        });
      }
    }
    return () => stopScheduler();
  }, [settings]);

  const unlockOnce = () => {
    if (!audioUnlocked.current) {
      unlockAudio();
      audioUnlocked.current = true;
    }
  };

  const handleSave = () => {
    unlockOnce();
    updateMutation.mutate({ data: form });
  };

  const handleTestAlarm = () => {
    unlockOnce();
    setTesting(true);
    setAlarmVisible(true);
    startAlarm();
    // Stop test after 8 s automatically if not dismissed
    setTimeout(() => {
      if (!alarmVisible) {
        stopAlarm();
        setTesting(false);
      }
    }, 8000);
  };

  const handleDismiss = () => {
    setAlarmVisible(false);
    setTesting(false);
  };

  const requestBrowserPermission = async () => {
    if (!("Notification" in window)) {
      toast({ title: "Not supported", description: "This browser doesn't support notifications.", variant: "destructive" });
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setForm((prev) => ({ ...prev, pushEnabled: true }));
      toast({ title: "Push notifications enabled!" });
    } else {
      toast({ title: "Permission denied", description: "Allow notifications in your browser settings.", variant: "destructive" });
    }
  };

  const toggleDay = (day: number) => {
    setForm((prev) => ({
      ...prev,
      reminderDays: prev.reminderDays.includes(day)
        ? prev.reminderDays.filter((d) => d !== day)
        : [...prev.reminderDays, day].sort(),
    }));
  };

  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];

  if (isLoading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <AlarmOverlay
        isOpen={alarmVisible}
        onDismiss={handleDismiss}
        dutyType={undefined}
        userName={user?.displayName}
      />

      <div className="max-w-2xl mx-auto space-y-6 pb-24">
        <div>
          <h1 className="text-3xl font-bold">Alarm Settings</h1>
          <p className="text-muted-foreground mt-1">
            Configure when the alarm fires and test it.
          </p>
        </div>

        {/* How it works notice */}
        <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-sm">
          <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div className="text-amber-900 space-y-1">
            <p className="font-semibold">About silent-mode bypass</p>
            <p>
              <span className="font-medium">Android / Chrome:</span> The alarm uses the browser's audio engine which is classified as media — it rings through vibrate-only and silent mode in most cases.
            </p>
            <p>
              <span className="font-medium">iOS / Safari:</span> Apple's system-level silent switch cannot be bypassed by any web app. The alarm will still show on screen.
            </p>
          </div>
        </div>

        {/* Alarm time & days */}
        <Card className="space-y-6">
          <div className="flex items-center gap-2 pb-2 border-b border-border">
            <AlarmClock className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold">Force Alarm</h2>
            {isAdmin && (
              <span className="ml-auto text-xs bg-primary/10 text-primary font-semibold px-2 py-0.5 rounded-full">
                Admin
              </span>
            )}
          </div>

          {/* Alarm enabled toggle */}
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">Enable alarm</p>
              <p className="text-sm text-muted-foreground">
                Rings loudly at the set time, even in silent mode (Android).
              </p>
            </div>
            <button
              onClick={() =>
                setForm((p) => ({ ...p, localAlarmEnabled: !p.localAlarmEnabled }))
              }
              className={`w-14 h-7 rounded-full transition-colors relative shrink-0 ${
                form.localAlarmEnabled ? "bg-primary" : "bg-border"
              }`}
            >
              <div
                className={`w-6 h-6 bg-white rounded-full absolute top-0.5 shadow transition-transform ${
                  form.localAlarmEnabled ? "translate-x-7" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>

          {/* Time picker */}
          <div className="space-y-2">
            <label className="text-sm font-semibold flex items-center gap-1.5 text-foreground/80">
              <Clock className="w-4 h-4" /> Alarm Time
            </label>
            <input
              type="time"
              value={form.reminderTime}
              onChange={(e) =>
                setForm((p) => ({ ...p, reminderTime: e.target.value }))
              }
              className="w-full sm:max-w-[200px] px-4 py-3 bg-white border-2 border-border rounded-xl text-foreground font-mono text-lg focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10"
            />
          </div>

          {/* Day selection */}
          <div className="space-y-3">
            <label className="text-sm font-semibold flex items-center gap-1.5 text-foreground/80">
              <CalendarDays className="w-4 h-4" /> Alarm Days
            </label>
            <div className="flex flex-wrap gap-2">
              {days.map((day, i) => {
                const active = form.reminderDays.includes(i);
                return (
                  <button
                    key={day}
                    onClick={() => toggleDay(i)}
                    className={`w-14 h-14 rounded-2xl font-semibold text-sm transition-all duration-200 border-2 ${
                      active
                        ? "bg-primary text-white border-primary shadow-md shadow-primary/30"
                        : "bg-white border-border text-muted-foreground hover:border-primary/40"
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Test alarm button */}
          <div className="pt-2 border-t border-border flex flex-col sm:flex-row gap-3">
            <Button
              variant="secondary"
              onClick={handleTestAlarm}
              className="flex items-center gap-2"
              disabled={testing}
            >
              <Volume2 className="w-4 h-4" />
              {testing ? "Ringing…" : "Test Alarm Now"}
            </Button>
            <Button
              onClick={handleSave}
              isLoading={updateMutation.isPending}
              className="flex-1 sm:flex-none"
            >
              Save Alarm Settings
            </Button>
          </div>
        </Card>

        {/* Push notifications */}
        <Card className="space-y-5">
          <div className="flex items-center gap-2 pb-2 border-b border-border">
            <Bell className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold">Push Notifications</h2>
          </div>

          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="font-semibold">Browser notifications</p>
              <p className="text-sm text-muted-foreground">
                Show a system notification when it's your duty day (requires permission).
              </p>
            </div>
            <Button
              variant={form.pushEnabled ? "outline" : "primary"}
              size="sm"
              onClick={
                form.pushEnabled
                  ? () => setForm((p) => ({ ...p, pushEnabled: false }))
                  : requestBrowserPermission
              }
              className="shrink-0"
            >
              {form.pushEnabled ? "Disable" : "Enable"}
            </Button>
          </div>

          <div className="flex items-start gap-3 p-3 bg-muted/40 rounded-xl text-xs text-muted-foreground">
            <Smartphone className="w-4 h-4 shrink-0 mt-0.5" />
            <p>
              Add this app to your home screen for the best notification experience on mobile. The force alarm works best when the browser tab stays open or as a PWA.
            </p>
          </div>
        </Card>
      </div>
    </>
  );
}
