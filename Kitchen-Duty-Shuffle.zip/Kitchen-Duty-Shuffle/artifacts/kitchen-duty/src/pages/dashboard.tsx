import React from "react";
import { format, isSameDay } from "date-fns";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useGetCurrentSchedule, useGetTodayAssignment } from "@workspace/api-client-react";
import { Card, Avatar, Button } from "@/components/ui-elements";
import { CheckCircle2, Utensils, Droplets, Calendar, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: schedule, isLoading: schedLoading } = useGetCurrentSchedule();
  const { data: today, isLoading: todayLoading } = useGetTodayAssignment();

  const isWeekend = !today?.riceAssignment && !today?.dishesAssignment;

  const totalTasks = schedule?.assignments.length || 0;
  const completedTasks = schedule?.assignments.filter(a => a.completed).length || 0;
  const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
        <h1 className="text-3xl md:text-4xl font-display font-bold">
          Hello, {user?.displayName}! 👋
        </h1>
        <p className="text-muted-foreground mt-2 text-lg">Here's your kitchen duty overview for this week.</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Task Highlight */}
        <div className="lg:col-span-2">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Calendar className="text-primary w-5 h-5" /> Today's Assignments
          </h2>
          
          <Card delay={0.1} className="bg-gradient-to-br from-white to-orange-50/50 border-orange-100">
            {todayLoading ? (
              <div className="h-32 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>
            ) : isWeekend ? (
              <div className="py-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold">It's the weekend!</h3>
                <p className="text-muted-foreground mt-1">No kitchen duties today. Enjoy your rest.</p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  {/* Rice */}
                  <div className="flex-1 bg-white p-4 rounded-2xl border border-black/5 shadow-sm flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-orange-100 flex items-center justify-center text-orange-600">
                      <Utensils className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Cook Rice</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Avatar name={today?.riceAssignment?.user?.displayName || "?"} color={today?.riceAssignment?.user?.avatarColor} className="w-6 h-6 text-[10px]" />
                        <span className="font-bold text-lg">{today?.riceAssignment?.user?.displayName}</span>
                      </div>
                    </div>
                    {today?.riceAssignment?.completed && (
                      <CheckCircle2 className="ml-auto w-6 h-6 text-success" />
                    )}
                  </div>

                  {/* Dishes */}
                  <div className="flex-1 bg-white p-4 rounded-2xl border border-black/5 shadow-sm flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
                      <Droplets className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Wash Dishes</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Avatar name={today?.dishesAssignment?.user?.displayName || "?"} color={today?.dishesAssignment?.user?.avatarColor} className="w-6 h-6 text-[10px]" />
                        <span className="font-bold text-lg">{today?.dishesAssignment?.user?.displayName}</span>
                      </div>
                    </div>
                    {today?.dishesAssignment?.completed && (
                      <CheckCircle2 className="ml-auto w-6 h-6 text-success" />
                    )}
                  </div>
                </div>

                {today?.myAssignment && (
                  <div className="pt-4 border-t border-black/5 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div>
                      <p className="font-bold text-lg">You have a task today!</p>
                      <p className="text-muted-foreground text-sm">Don't forget to mark it as done.</p>
                    </div>
                    <Link href="/today" className="w-full sm:w-auto">
                      <Button className="w-full sm:w-auto group">
                        Go to My Task <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>

        {/* Weekly Progress */}
        <div className="lg:col-span-1">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            Weekly Progress
          </h2>
          <Card delay={0.2} className="h-[calc(100%-2.5rem)] flex flex-col justify-center text-center">
            {schedLoading ? (
              <div className="py-8 flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>
            ) : !schedule ? (
              <div className="py-8">
                <p className="text-muted-foreground">No schedule generated for this week.</p>
              </div>
            ) : (
              <div>
                <div className="relative w-32 h-32 mx-auto mb-6">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" className="stroke-muted fill-none" strokeWidth="8" />
                    <circle 
                      cx="50" cy="50" r="40" 
                      className="stroke-primary fill-none transition-all duration-1000 ease-out" 
                      strokeWidth="8" 
                      strokeLinecap="round"
                      strokeDasharray="251.2"
                      strokeDashoffset={251.2 - (251.2 * progress) / 100}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <span className="text-3xl font-display font-bold">{Math.round(progress)}%</span>
                  </div>
                </div>
                <h3 className="font-bold text-lg">{completedTasks} of {totalTasks} duties</h3>
                <p className="text-muted-foreground text-sm">completed this week</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
