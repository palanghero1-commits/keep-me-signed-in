import React from "react";
import { format } from "date-fns";
import { useGetCurrentSchedule } from "@workspace/api-client-react";
import { Card, Avatar } from "@/components/ui-elements";
import { Utensils, Droplets, CheckCircle2, Loader2, CalendarX2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Schedule() {
  const { data: schedule, isLoading } = useGetCurrentSchedule();

  if (isLoading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  if (!schedule || schedule.days.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="w-24 h-24 bg-black/5 text-muted-foreground rounded-full flex items-center justify-center">
          <CalendarX2 className="w-12 h-12" />
        </div>
        <h1 className="text-2xl font-bold">No Schedule Yet</h1>
        <p className="text-muted-foreground">The admin hasn't generated a schedule for this week.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold">Weekly Schedule</h1>
        <p className="text-muted-foreground">
          {format(new Date(schedule.schedule.weekStartDate), "MMM d")} - {format(new Date(schedule.schedule.weekEndDate), "MMM d, yyyy")}
        </p>
      </div>

      <div className="hidden md:block">
        {/* Desktop Table View */}
        <Card className="overflow-hidden p-0 border-0 shadow-lg">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-black/5">
                <th className="px-6 py-4 font-bold text-foreground">Day</th>
                <th className="px-6 py-4 font-bold text-foreground">
                  <div className="flex items-center gap-2"><Utensils className="w-5 h-5 text-orange-500"/> Cook Rice</div>
                </th>
                <th className="px-6 py-4 font-bold text-foreground">
                  <div className="flex items-center gap-2"><Droplets className="w-5 h-5 text-blue-500"/> Wash Dishes</div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {schedule.days.map((day, i) => (
                <tr key={day.date} className="hover:bg-black/[0.02] transition-colors">
                  <td className="px-6 py-5">
                    <p className="font-bold">{day.dayName}</p>
                    <p className="text-sm text-muted-foreground">{format(new Date(day.date), "MMM d")}</p>
                  </td>
                  <td className="px-6 py-5">
                    {day.riceAssignment && (
                      <div className="flex items-center gap-3">
                        <Avatar name={day.riceAssignment.user?.displayName || "?"} color={day.riceAssignment.user?.avatarColor} />
                        <span className="font-medium">{day.riceAssignment.user?.displayName}</span>
                        {day.riceAssignment.completed && <CheckCircle2 className="w-5 h-5 text-success ml-auto" />}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-5">
                    {day.dishesAssignment && (
                      <div className="flex items-center gap-3">
                        <Avatar name={day.dishesAssignment.user?.displayName || "?"} color={day.dishesAssignment.user?.avatarColor} />
                        <span className="font-medium">{day.dishesAssignment.user?.displayName}</span>
                        {day.dishesAssignment.completed && <CheckCircle2 className="w-5 h-5 text-success ml-auto" />}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="md:hidden space-y-4">
        {/* Mobile List View */}
        {schedule.days.map((day, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={day.date} 
            className="bg-white rounded-2xl border border-border shadow-sm overflow-hidden"
          >
            <div className="bg-black/5 px-4 py-3 border-b border-border flex justify-between items-center">
              <span className="font-bold">{day.dayName}</span>
              <span className="text-sm text-muted-foreground">{format(new Date(day.date), "MMM d")}</span>
            </div>
            <div className="p-4 space-y-4">
              {day.riceAssignment && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
                      <Utensils className="w-4 h-4" />
                    </div>
                    <Avatar name={day.riceAssignment.user?.displayName || "?"} color={day.riceAssignment.user?.avatarColor} className="w-8 h-8 text-xs" />
                    <span className="font-medium">{day.riceAssignment.user?.displayName}</span>
                  </div>
                  {day.riceAssignment.completed && <CheckCircle2 className="w-5 h-5 text-success" />}
                </div>
              )}
              {day.dishesAssignment && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                      <Droplets className="w-4 h-4" />
                    </div>
                    <Avatar name={day.dishesAssignment.user?.displayName || "?"} color={day.dishesAssignment.user?.avatarColor} className="w-8 h-8 text-xs" />
                    <span className="font-medium">{day.dishesAssignment.user?.displayName}</span>
                  </div>
                  {day.dishesAssignment.completed && <CheckCircle2 className="w-5 h-5 text-success" />}
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
