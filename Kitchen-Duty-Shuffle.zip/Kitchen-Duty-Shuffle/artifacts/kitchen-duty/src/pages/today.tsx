import React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useGetTodayAssignment, useCompleteTask, useUncompleteTask } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Card, Avatar, Button } from "@/components/ui-elements";
import { CheckCircle2, Utensils, Droplets, Loader2, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Today() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { data: today, isLoading } = useGetTodayAssignment();
  
  const completeMutation = useCompleteTask({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/today"] });
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/current"] });
      }
    }
  });

  const uncompleteMutation = useUncompleteTask({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/today"] });
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/current"] });
      }
    }
  });

  if (isLoading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  const isWeekend = !today?.riceAssignment && !today?.dishesAssignment;

  if (isWeekend) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="w-24 h-24 bg-primary/10 text-primary rounded-full flex items-center justify-center">
          <Sparkles className="w-12 h-12" />
        </div>
        <h1 className="text-3xl font-display font-bold">It's the Weekend!</h1>
        <p className="text-muted-foreground text-lg">Take a break from the kitchen.</p>
      </div>
    );
  }

  const handleToggle = (assignmentId: number, isCompleted: boolean) => {
    if (isCompleted) {
      uncompleteMutation.mutate({ assignmentId });
    } else {
      completeMutation.mutate({ assignmentId });
    }
  };

  const renderDutyCard = (assignment: any, type: "rice" | "dishes") => {
    if (!assignment) return null;
    const isMine = assignment.userId === user?.id;
    const Icon = type === "rice" ? Utensils : Droplets;
    const colorClass = type === "rice" ? "bg-orange-100 text-orange-600 border-orange-200" : "bg-blue-100 text-blue-600 border-blue-200";
    
    return (
      <Card delay={type === "rice" ? 0.1 : 0.2} className={`relative overflow-hidden transition-all duration-300 ${isMine && !assignment.completed ? 'ring-2 ring-primary ring-offset-4 ring-offset-background' : ''}`}>
        {assignment.completed && (
          <div className="absolute top-0 right-0 bg-success text-white px-4 py-1 rounded-bl-2xl font-bold text-sm flex items-center gap-1 shadow-md">
            <CheckCircle2 className="w-4 h-4" /> Done
          </div>
        )}
        
        <div className="flex flex-col items-center text-center pt-4">
          <div className={`w-20 h-20 rounded-3xl ${colorClass} flex items-center justify-center shadow-inner mb-4`}>
            <Icon className="w-10 h-10" />
          </div>
          <h2 className="text-xl font-bold uppercase tracking-widest text-muted-foreground mb-4">
            {type === "rice" ? "Cook Rice" : "Wash Dishes"}
          </h2>
          
          <div className="flex items-center gap-3 bg-black/5 px-6 py-3 rounded-full mb-8">
            <Avatar name={assignment.user?.displayName || "?"} color={assignment.user?.avatarColor} />
            <span className="font-bold text-xl">{assignment.user?.displayName}</span>
          </div>

          {isMine ? (
            <Button
              size="lg"
              variant={assignment.completed ? "outline" : "primary"}
              className="w-full"
              isLoading={completeMutation.isPending || uncompleteMutation.isPending}
              onClick={() => handleToggle(assignment.id, assignment.completed)}
            >
              {assignment.completed ? "Undo Completion" : "Mark as Done"}
            </Button>
          ) : (
            <div className="h-[52px] flex items-center justify-center text-muted-foreground font-medium bg-black/5 rounded-xl w-full">
              {assignment.completed ? "Task Completed" : "Waiting for completion..."}
            </div>
          )}
        </div>
      </Card>
    );
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-display font-bold mb-2">Today's Tasks</h1>
        <p className="text-lg text-primary font-medium">
          {today?.date ? format(new Date(today.date), "EEEE, MMMM d") : "Loading..."}
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {renderDutyCard(today?.riceAssignment, "rice")}
        {renderDutyCard(today?.dishesAssignment, "dishes")}
      </div>
    </div>
  );
}
