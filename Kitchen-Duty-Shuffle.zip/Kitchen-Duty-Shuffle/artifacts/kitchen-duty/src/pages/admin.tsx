import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetCurrentSchedule, useGenerateSchedule, useListUsers, useUpdateAssignment } from "@workspace/api-client-react";
import { Card, Button, Avatar } from "@/components/ui-elements";
import { Loader2, Plus, Edit2, X } from "lucide-react";
import { format } from "date-fns";

export default function Admin() {
  const queryClient = useQueryClient();
  const { data: schedule, isLoading: schedLoading } = useGetCurrentSchedule();
  const { data: users, isLoading: usersLoading } = useListUsers();
  
  const generateMutation = useGenerateSchedule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/current"] });
      }
    }
  });

  const updateMutation = useUpdateAssignment({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/schedule/current"] });
        setEditingCell(null);
      }
    }
  });

  const [editingCell, setEditingCell] = useState<{dayIndex: number, type: 'rice'|'dishes'} | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<number | "">("");

  if (schedLoading || usersLoading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  const handleGenerate = () => {
    if (confirm("Are you sure you want to generate a new schedule for next week? This will override any unsaved changes.")) {
      generateMutation.mutate({ data: {} });
    }
  };

  const handleSave = (dayOfWeek: number, dutyType: 'rice'|'dishes') => {
    if (!selectedUserId || !schedule?.schedule.id) return;
    updateMutation.mutate({
      scheduleId: schedule.schedule.id,
      data: { userId: Number(selectedUserId), dayOfWeek, dutyType }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold">Manage Schedule</h1>
          <p className="text-muted-foreground">Administer the kitchen duty assignments.</p>
        </div>
        <Button onClick={handleGenerate} isLoading={generateMutation.isPending} className="flex items-center gap-2">
          <Plus className="w-5 h-5" /> Generate Next Week
        </Button>
      </div>

      {!schedule || schedule.days.length === 0 ? (
        <Card className="text-center py-12">
          <p className="text-muted-foreground mb-4">No active schedule found.</p>
          <Button onClick={handleGenerate} isLoading={generateMutation.isPending}>
            Generate Now
          </Button>
        </Card>
      ) : (
        <Card className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-black/5">
                <th className="px-6 py-4 font-bold">Day</th>
                <th className="px-6 py-4 font-bold">Cook Rice</th>
                <th className="px-6 py-4 font-bold">Wash Dishes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {schedule.days.map((day, i) => (
                <tr key={day.date} className="hover:bg-black/[0.02]">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="font-bold block">{day.dayName}</span>
                    <span className="text-sm text-muted-foreground">{format(new Date(day.date), "MMM d")}</span>
                  </td>
                  
                  {/* Rice Column */}
                  <td className="px-6 py-4 relative group">
                    {editingCell?.dayIndex === i && editingCell.type === 'rice' ? (
                      <div className="flex items-center gap-2">
                        <select 
                          className="border border-border rounded-lg px-2 py-1.5 focus:ring-2 focus:ring-primary/20 outline-none"
                          value={selectedUserId}
                          onChange={e => setSelectedUserId(e.target.value as any)}
                        >
                          <option value="" disabled>Select User</option>
                          {users?.map(u => <option key={u.id} value={u.id}>{u.displayName}</option>)}
                        </select>
                        <Button size="sm" onClick={() => handleSave(i, 'rice')} isLoading={updateMutation.isPending}>Save</Button>
                        <button onClick={() => setEditingCell(null)} className="p-1.5 text-muted-foreground hover:text-foreground"><X className="w-4 h-4"/></button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar name={day.riceAssignment?.user?.displayName || "?"} color={day.riceAssignment?.user?.avatarColor} className="w-8 h-8 text-xs" />
                          <span>{day.riceAssignment?.user?.displayName || "Unassigned"}</span>
                        </div>
                        <button 
                          onClick={() => { setEditingCell({dayIndex: i, type: 'rice'}); setSelectedUserId(day.riceAssignment?.userId || ""); }}
                          className="p-2 text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>

                  {/* Dishes Column */}
                  <td className="px-6 py-4 relative group">
                    {editingCell?.dayIndex === i && editingCell.type === 'dishes' ? (
                      <div className="flex items-center gap-2">
                        <select 
                          className="border border-border rounded-lg px-2 py-1.5 focus:ring-2 focus:ring-primary/20 outline-none"
                          value={selectedUserId}
                          onChange={e => setSelectedUserId(e.target.value as any)}
                        >
                          <option value="" disabled>Select User</option>
                          {users?.map(u => <option key={u.id} value={u.id}>{u.displayName}</option>)}
                        </select>
                        <Button size="sm" onClick={() => handleSave(i, 'dishes')} isLoading={updateMutation.isPending}>Save</Button>
                        <button onClick={() => setEditingCell(null)} className="p-1.5 text-muted-foreground hover:text-foreground"><X className="w-4 h-4"/></button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar name={day.dishesAssignment?.user?.displayName || "?"} color={day.dishesAssignment?.user?.avatarColor} className="w-8 h-8 text-xs" />
                          <span>{day.dishesAssignment?.user?.displayName || "Unassigned"}</span>
                        </div>
                        <button 
                          onClick={() => { setEditingCell({dayIndex: i, type: 'dishes'}); setSelectedUserId(day.dishesAssignment?.userId || ""); }}
                          className="p-2 text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}
