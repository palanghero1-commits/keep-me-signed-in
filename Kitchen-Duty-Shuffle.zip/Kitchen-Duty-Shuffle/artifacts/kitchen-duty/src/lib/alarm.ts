/**
 * Alarm Engine using Web Audio API.
 *
 * Web Audio API audio is classified as "media" by browsers, which means
 * on Android/Chrome it can play through silent/DND mode. On iOS Safari
 * silent mode always wins — that's a system-level restriction no web app
 * can bypass.
 *
 * The alarm runs a repeating beep pattern until explicitly stopped.
 */

let audioCtx: AudioContext | null = null;
let alarmInterval: ReturnType<typeof setInterval> | null = null;
let beepTimeout: ReturnType<typeof setTimeout> | null = null;
let isRinging = false;

function getCtx(): AudioContext {
  if (!audioCtx || audioCtx.state === "closed") {
    audioCtx = new AudioContext();
  }
  return audioCtx;
}

/** Play a single beep: frequency Hz, duration ms, volume 0-1 */
function beep(freq: number, duration: number, volume: number, startTime: number): void {
  const ctx = getCtx();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.type = "square";
  osc.frequency.setValueAtTime(freq, startTime);

  // Hard attack, fast decay for a piercing alarm tone
  gain.gain.setValueAtTime(0, startTime);
  gain.gain.linearRampToValueAtTime(volume, startTime + 0.01);
  gain.gain.setValueAtTime(volume, startTime + duration / 1000 - 0.05);
  gain.gain.linearRampToValueAtTime(0, startTime + duration / 1000);

  osc.start(startTime);
  osc.stop(startTime + duration / 1000);
}

/**
 * Play one cycle of the alarm pattern: three sharp beeps.
 * Total cycle ~1.4 s, then silence until next cycle.
 */
function playAlarmCycle(): void {
  const ctx = getCtx();
  const now = ctx.currentTime;

  // Three ascending beeps (piercing at max volume)
  beep(880, 200, 1.0, now + 0.0);
  beep(1100, 200, 1.0, now + 0.3);
  beep(1320, 350, 1.0, now + 0.6);
}

/** Start the repeating alarm (beep every 2 seconds) */
export function startAlarm(): void {
  if (isRinging) return;
  isRinging = true;

  // Resume context if suspended (required after user gesture on some browsers)
  const ctx = getCtx();
  if (ctx.state === "suspended") {
    ctx.resume();
  }

  playAlarmCycle();
  alarmInterval = setInterval(() => {
    if (isRinging) playAlarmCycle();
  }, 2000);
}

/** Stop the alarm */
export function stopAlarm(): void {
  isRinging = false;
  if (alarmInterval !== null) {
    clearInterval(alarmInterval);
    alarmInterval = null;
  }
  if (beepTimeout !== null) {
    clearTimeout(beepTimeout);
    beepTimeout = null;
  }
  // Close and reset context so next alarm starts fresh
  if (audioCtx && audioCtx.state !== "closed") {
    audioCtx.close().catch(() => {});
    audioCtx = null;
  }
}

export function isAlarmRinging(): boolean {
  return isRinging;
}

/**
 * Unlock the AudioContext on first user interaction.
 * Must be called once (on a button click, etc.) to allow audio
 * to play on mobile browsers that require a user gesture.
 */
export function unlockAudio(): void {
  const ctx = getCtx();
  if (ctx.state === "suspended") {
    ctx.resume();
  }
  // Play a silent buffer to unlock
  const buf = ctx.createBuffer(1, 1, 22050);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.connect(ctx.destination);
  src.start(0);
}

// ─── Scheduler ───────────────────────────────────────────────────────────────

type AlarmCallback = () => void;
let schedulerInterval: ReturnType<typeof setInterval> | null = null;
let alarmCallback: AlarmCallback | null = null;

/**
 * Start the alarm scheduler.
 * Checks the current time every 30 s. When it matches the configured
 * alarm time (HH:MM) on an enabled day, fires `callback`.
 *
 * @param reminderTime  "HH:MM" string
 * @param reminderDays  array of day indices 0=Mon … 4=Fri
 * @param callback      called when alarm fires
 */
export function startScheduler(
  reminderTime: string,
  reminderDays: number[],
  callback: AlarmCallback
): void {
  stopScheduler();
  alarmCallback = callback;

  const check = () => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0=Sun … 6=Sat
    const appDay = dayOfWeek - 1; // convert to 0=Mon … 4=Fri

    if (!reminderDays.includes(appDay)) return;

    const [hStr, mStr] = reminderTime.split(":");
    const alarmH = parseInt(hStr ?? "0", 10);
    const alarmM = parseInt(mStr ?? "0", 10);

    if (now.getHours() === alarmH && now.getMinutes() === alarmM) {
      alarmCallback?.();
    }
  };

  // Run immediately, then every 30 s
  check();
  schedulerInterval = setInterval(check, 30_000);
}

export function stopScheduler(): void {
  if (schedulerInterval !== null) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
  }
}
